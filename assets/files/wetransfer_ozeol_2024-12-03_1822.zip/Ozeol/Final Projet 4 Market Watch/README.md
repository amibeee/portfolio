
# Market Watch - Ozeol.com

## Project Objective

Market Watch is a comprehensive Market Surveillance Tool designed to monitor and display the liquidation status of companies. By aggregating data from various merchant websites, this tool offers real-time insights into actionable business opportunities.

## Table of Contents

- [Description](#description)
- [Installation](#installation)
- [Usage](#usage)
- [Features](#features)
- [Project Structure](#project-structure)
- [Technologies Used](#technologies-used)
- [Contributing](#contributing)
- [Demo & Screenshots](#demo-screenshots)
- [License](#license)
- [Acknowledgments](#acknowledgments)
- [Contact Information](#contact-information)

## Description

Market Watch is an essential tool for businesses looking to capitalize on liquidation events. The application scrapes data from multiple online sources, analyzes it, and presents it in an easily digestible format. Whether you're in retail or investment, this tool provides the insights needed to make informed decisions.

## Installation

To set up and run this project locally, follow these steps:

1. **Clone the repository:**

   ```bash
   git clone https://github.com/+++++++
   ```

2. **Navigate to the repository directory:**

   ```bash
   cd market-watch-ozeol
   ```

3. **Install the required libraries:**

   ```bash
   pip install Flask pandas flask_sqlalchemy sqlalchemy importlib dotenv flask_login os random requests
   ```

## Usage

To launch the project, run the following command:

```bash
python run.py
```

Once the Flask application is running, open your web browser and go to `http://localhost:5000` to access the tool.

## Features

- **Real-Time Data Collection:** Scrapes and updates data from multiple merchant websites.
- **User Authentication:** Secure login and account management.
- **Dashboard:** Visual representation of key metrics and trends.
- **Custom Notifications:** Alerts on new liquidation opportunities.
- **Responsive Design:** Optimized for both desktop and mobile devices.

## Project Structure

```
market-watch-ozeol/
│
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── static/
│   │   ├── css/
│   │   ├── demo/
│   │   ├── fonts/
│   │   ├── img/
│   │   ├── js/
│   │   └── scss/
│   ├── templates/
│   └── ...
├── apps/
│   ├── __init__.py
│   ├── models.py
│   ├── authentication/
│   │   ├── __init__.py
│   │   ├── forms.py
│   │   ├── models.py
│   │   └── util.py
│   ├── home/
│   │   ├── __init__.py
│   │   ├── routes.py
│   │   └── templates/
│   └── ...
└── run.py
```

## Technologies Used

- **HTML5:** Defines the structure of the web pages.
- **CSS3:** Provides styling and layout.
- **JavaScript:** Adds interactivity and dynamic content.
- **Flask:** A lightweight WSGI web application framework.
- **SQLAlchemy:** SQL toolkit and Object-Relational Mapping (ORM) library for Python.
- **Pandas:** Data manipulation and analysis library.
- **Flask-Login:** Manages user sessions.

## Contributing

Contributions are welcome! If you have suggestions for improvements or wish to report any issues, feel free to submit a pull request or open an issue.

## Demo & Screenshots

![Dark mode](image.png)
![Light mode](image-1.png)
![Table](image-2.png)
![Dashboard](image-3.png)

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for more details.

## Acknowledgments

- This project was inspired by [GitHub Project](https://market.com) and similar market surveillance tools.

## Contact Information

For further information, please contact:

- **Name:** Projet 4
- **Email:** projet4-ai@ozeol.com

