document.querySelector('.search').addEventListener('input', function (event) {
    const searchTerm = event.target.value.toLowerCase();
    const rows = document.querySelectorAll('.suppliers-table tbody tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const match = Array.from(cells).some(cell => cell.textContent.toLowerCase().includes(searchTerm));
        row.style.display = match ? '' : 'none';
    });
});

document.querySelector('.logout').addEventListener('click', function () {
    window.location.href = 'login.html'; // Redirect to login page on logout
});

document.querySelectorAll('.stat').forEach(stat => {
    stat.addEventListener('mouseover', () => {
        stat.style.transform = 'translateY(-5px)';
    });
    stat.addEventListener('mouseout', () => {
        stat.style.transform = 'translateY(0)';
    });
});

    document.addEventListener('DOMContentLoaded', () => {
        const toggleDarkMode = document.getElementById('dark-mode-toggle');
        
        // Load dark mode preference from localStorage
        if (localStorage.getItem('dark-mode') === 'enabled') {
            document.body.classList.add('dark-mode');
        }

        toggleDarkMode.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            
            // Save the current preference to localStorage
            if (document.body.classList.contains('dark-mode')) {
                localStorage.setItem('dark-mode', 'enabled');
            } else {
                localStorage.setItem('dark-mode', 'disabled');
            }
        });
    });



