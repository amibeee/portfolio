from flask import Flask, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from app.config import Config
from flask import Flask
from flask_login import LoginManager
db = SQLAlchemy()
loginmanager = LoginManager()

def create_app():
    app = Flask(__name__)
 
    loginmanager.init_app(app)
    app.config.from_object(Config)
    db.init_app(app)

    from apps.home.routes import home_blueprint
    app.register_blueprint(home_blueprint)

    # Définir la route pour servir les fichiers statiques
    @app.route('/static/<path:filename>')
    def serve_static(filename):
        return send_from_directory('static', filename)

    return app
