import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('test') or 'test'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'mysql://root:vU=sZJuvwKLvKoq1`L";@192.168.11.8/projet4'
    SQLALCHEMY_TRACK_MODIFICATIONS = False