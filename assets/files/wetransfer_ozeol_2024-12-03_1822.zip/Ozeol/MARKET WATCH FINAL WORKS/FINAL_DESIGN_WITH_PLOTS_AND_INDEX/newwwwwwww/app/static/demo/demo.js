var demo = {

    // Theme colors with further reduced transparency (using RGBA format, opacity set to 0.4)
    themeColors: [
        'rgba(234, 84, 45, 0.4)',  // #ea542d with 40% opacity
        'rgba(255, 99, 132, 0.4)', // Lighter Coral
        'rgba(255, 159, 64, 0.4)', // Soft Orange
        'rgba(75, 192, 192, 0.4)', // Light Teal
        'rgba(153, 102, 255, 0.4)',// Soft Purple
        'rgba(255, 205, 86, 0.4)'  // Soft Yellow
    ],

    // Function to shuffle an array
    shuffleArray: function(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    },

    // Function to get a randomized color from the theme colors
    getRandomizedColors: function(length) {
        // Clone and shuffle the theme colors array
        let shuffledColors = this.shuffleArray([...this.themeColors]);
        // If more colors are needed, repeat the shuffled colors
        return Array.from({ length }, (_, i) => shuffledColors[i % shuffledColors.length]);
    },

    initStackedBarChart: function(chartData) {
        var ctx = document.getElementById('stackedbarchart').getContext('2d');
        var randomizedColors = this.getRandomizedColors(chartData.datasets.length);

        var stackedBarChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: chartData.datasets.map((dataset, index) => ({
                    ...dataset,
                    backgroundColor: randomizedColors[index],
                }))
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        stacked: true,
                        gridLines: {
                            display: false
                        },
                        ticks: {
                            fontColor: '#9aa0ac',
                            fontSize: 14
                        }
                    },
                    y: {
                        stacked: true,
                        gridLines: {
                            color: 'rgba(0, 0, 0, 0.1)',
                            zeroLineColor: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            fontColor: '#9aa0ac',
                            fontSize: 14,
                            callback: function(value) {
                                return value.toLocaleString();
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            fontColor: '#9aa0ac',
                            fontSize: 14
                        }
                    }
                }
            }
        });
    },

    initDoughnutChart: function(chartData) {
        var ctx = document.getElementById('donutchart').getContext('2d');
        var randomizedColors = this.getRandomizedColors(chartData.datasets[0].data.length);

        var doughnutChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: chartData.labels,
                datasets: [{
                    data: chartData.datasets[0].data,
                    backgroundColor: randomizedColors,
                    borderColor: 'rgba(0, 0, 0, 0.1)', // Lighter border color
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Affair Result'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var label = context.label || '';
                                var dataIndex = context.dataIndex;
                                if (label) {
                                    label += ': ';
                                }
                                // Access the number of affairs from chartData
                                var value = chartData.datasets[0].data[dataIndex];
                                // Display IDAct based on the segment
                                var affairList = dataIndex === 0 ? chartData.noAffairs : chartData.yesAffairs;
                                var affairDetails = affairList.map(affair => `IdAct: ${affair}`).join(', ');

                                return `${label}${value} (${affairDetails})`;
                            }
                        }
                    }
                }
            }
        });
    },

    initStatutactPieChart: function(statutactChartData) {
        var ctxStatutact = document.getElementById('statutactChart').getContext('2d');
        var randomizedColors = this.getRandomizedColors(statutactChartData.labels.length);

        new Chart(ctxStatutact, {
            type: 'pie',
            data: {
                ...statutactChartData,
                datasets: statutactChartData.datasets.map((dataset) => ({
                    ...dataset,
                    backgroundColor: randomizedColors,
                }))
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Statut Act',
                        color: '#343a40'
                    },
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed !== null) {
                                    label += context.parsed;
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    },

    initMap: function(supplierData) {
        // Initialize the map
        var map = L.map('supplier-map').setView([20, 0], 2); // Set initial view to a global view

        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);

        // Add markers for each supplier
        supplierData.forEach(function(supplier) {
            L.marker(supplier.coordinates)
                .addTo(map)
                .bindPopup(supplier.name + "<br>" + supplier.country);
        });
    }
};
