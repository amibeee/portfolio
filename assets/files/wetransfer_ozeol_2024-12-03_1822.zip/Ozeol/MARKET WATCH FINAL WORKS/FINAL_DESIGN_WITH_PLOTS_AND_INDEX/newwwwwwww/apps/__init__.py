from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from app.config import Config
from app import db
import logging
import sqlalchemy
from importlib import import_module 

logging.basicConfig()
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)

def register_blueprints(app):
    for module_name in ('authentication', 'home'):
        module = import_module('apps.{}.routes'.format(module_name))
        app.register_blueprint(module.blueprint)

def create_app(config_class=Config):
    app = Flask(__name__, static_folder='apps/static', template_folder='templates')
    app.config.from_object(config_class)

    with app.app_context():
        try:
            # Try to connect to the database
            engine = sqlalchemy.create_engine(app.config['SQLALCHEMY_DATABASE_URI'])
            engine.connect()
            print("Database connection successful")
        except sqlalchemy.exc.SQLAlchemyError as e:
            print(f"Database connection failed: {str(e)}")
            raise e

        db.init_app(app)

        from apps.home.routes import home_blueprint
        app.register_blueprint(home_blueprint)

        db.create_all()

    return app

