from flask_login import UserMixin
from sqlalchemy.orm import relationship
from flask_dance.consumer.storage.sqla import OAuthConsumerMixin
from app import db, loginmanager

class Users(db.Model, UserMixin):

    __tablename__ = 'accounts'
    id            = db.Column(db.Integer, primary_key=True)
    username      = db.Column(db.String(64), unique=True)
    password      = db.Column(db.LargeBinary)
    email         = db.Column(db.String(64), unique=True)
    
@loginmanager.user_loader
def user_loader(id):
    return Users.query.filter_by(id=id).first()

@loginmanager.request_loader
def request_loader(request):
    username = request.form.get('username')
    user = Users.query.filter_by(username=username).first()
    return user if user else None