def verify_pass(provided_password, stored_password):
    return provided_password==stored_password