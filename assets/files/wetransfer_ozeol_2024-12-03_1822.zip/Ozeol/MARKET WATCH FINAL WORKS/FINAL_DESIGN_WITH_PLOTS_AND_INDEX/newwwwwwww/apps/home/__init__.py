from apps.models import Supplier


def fetch_supplier_data(idfrs):
    supplier = Supplier.query.get(idfrs)
    if supplier:
        return {
            'IdFrs': supplier.IdFrs,
        }
    else:
        return None
    

from flask import Blueprint
home_blueprint = Blueprint('home', __name__, template_folder='templates')
from . import routes 