from flask import Blueprint, json, render_template, jsonify, request, redirect
from sqlalchemy import func
from apps.models import Supplier
from flask_login import login_required
from apps.authentication.forms import LoginForm
from apps.authentication.models import Users
from apps.authentication.util import verify_pass
from app import db, loginmanager
from flask_login import ( current_user, login_user, logout_user)
import random
import requests
 
home_blueprint = Blueprint('home', __name__, template_folder='templates')
 
@loginmanager.user_loader
def load_user(user_id):
    return Users.query.get(user_id)
 
@home_blueprint.route('/')
def index():
    return render_template('home/index.html')
 
@home_blueprint.route('/login', methods=['GET', 'POST'])
def login():
     login_form = LoginForm(request.form)
 
     if request.method == 'POST':
        if login_form.validate():
 
            # read form data
            username = request.form['username']
            password = request.form['password']
 
            # Locate user
            user = Users.query.filter_by(username=username).first()
            # return f"user: {user.username}, pass: {user.password}"
 
            # Check the password
            if user and verify_pass(password, user.password):
 
                login_user(user)
                return redirect('tables')
 
            # Something (user or pass) is not ok
            return render_template('accounts/login.html',
                                msg='Wrong user or password',
                                form=login_form)
       
     return render_template('accounts/login.html',form=login_form)
 
@home_blueprint.route('/tables')
@login_required
def tables():
    suppliers = Supplier.query.filter(Supplier.TitulaireFrs==current_user.id and Supplier.TitulaireFrs=='NULL'  ).all()
    return render_template('home/tables.html', suppliers=suppliers)
 
@home_blueprint.route('/notifications')
def notifications():
    return render_template('home/notifications.html')
 
def get_coordinates(country):
    api_key = 'd483ba3ff24148f5a0d4d248523a5192'
    url = f'https://api.opencagedata.com/geocode/v1/json?q={country}&key={api_key}'
   
    try:
        response = requests.get(url)
        data = response.json()
        if data['results']:
            return data['results'][0]['geometry']['lat'], data['results'][0]['geometry']['lng']
    except Exception as e:
        print(f"Error fetching coordinates: {e}")
   
    return 20, 0  # Default to a global view
 

@home_blueprint.route('/supplier/<string:idfrs>')
def supplier_details(idfrs):
    # Fetch the supplier
    supplier = Supplier.query.filter_by(IdFrs=idfrs).first()
    if not supplier:
        return "Supplier not found", 404

    # Supplier basic data
    suppliers = Supplier.query.with_entities(Supplier.IdFrs, Supplier.PaysFrs).filter_by(IdFrs=idfrs).distinct().all()
    supplier_data = [
        {
            'name': s.IdFrs,
            'country': s.PaysFrs,
            'coordinates': get_coordinates(s.PaysFrs)
        }
        for s in suppliers
    ]

    # Qualifications data
    qualifications = Supplier.query.with_entities(Supplier.QualifAct).filter_by(IdFrs=idfrs).distinct().all()
    qualifications = [q[0] for q in qualifications]

    # Stacked Bar Chart Data
    idacts = Supplier.query.with_entities(Supplier.IdAct, Supplier.QualifAct).filter_by(IdFrs=idfrs).distinct().all()
    stacked_bar_chart_data = {
        'labels': [],
        'datasets': []
    }

    for qualification in qualifications:
        dataset = {
            'label': qualification,
            'data': [0] * len(idacts),
            'backgroundColor': f'rgba({random.randint(0, 255)}, {random.randint(0, 255)}, {random.randint(0, 255)}, 0.2)',
            'borderColor': '#ea542d',
            'borderWidth': 1
        }
        stacked_bar_chart_data['datasets'].append(dataset)

    for i, (idact, qualifact) in enumerate(idacts):
        stacked_bar_chart_data['labels'].append(idact)
        for dataset in stacked_bar_chart_data['datasets']:
            if dataset['label'] == qualifact:
                dataset['data'][i] = 1

    idacts_affairs = Supplier.query.with_entities(Supplier.IdAct, Supplier.Affair).filter_by(IdFrs=idfrs).distinct().all()
    no_affairs = [idact for idact, affair in idacts_affairs if affair == '0']
    yes_affairs = [idact for idact, affair in idacts_affairs if affair == '1']

    donut_chart_data = {
        'labels': ['No', 'Yes'],
        'datasets': [{
            'label': 'Supplier Details',
            'data': [len(no_affairs), len(yes_affairs)],
            'backgroundColor': [],  # Colors will be generated dynamically
            'borderWidth': 1
        }],
        'noAffairs': no_affairs,
        'yesAffairs': yes_affairs
    }
    # Pie Chart Data
    type_frs_counts = Supplier.query.with_entities(Supplier.TypeFrs, func.count(Supplier.TypeFrs)).filter_by(IdFrs=idfrs).group_by(Supplier.TypeFrs).all()
    statut_frs_counts = Supplier.query.with_entities(Supplier.StatutFrs, func.count(Supplier.StatutFrs)).filter_by(IdFrs=idfrs).group_by(Supplier.StatutFrs).all()

    pie_chart_data = {
        'labels': [row[0] for row in type_frs_counts + statut_frs_counts],
        'datasets': [{
            'data': [row[1] for row in type_frs_counts] + [row[1] for row in statut_frs_counts],
            'backgroundColor': f'rgba({random.randint(0, 255)}, {random.randint(0, 255)}, {random.randint(0, 255)}, 0.2)',
        }]
    }

    # Statutact Pie Chart Data
    idacts_statutact = Supplier.query.with_entities(Supplier.IdAct, Supplier.StatutAct).filter_by(IdFrs=idfrs).distinct().all()
    statutact_data = {}
    for idact, statutact in idacts_statutact:
        statutact_data[statutact] = statutact_data.get(statutact, 0) + 1

    statutact_chart_data = {
        'labels': list(statutact_data.keys()),
        'datasets': [{
            'label': 'STATUTACT',
            'data': list(statutact_data.values()),
            'backgroundColor': ['#ea542d', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
            'borderWidth': 1
        }]
    }

    # Fetch all offers for the supplier
    offers = Supplier.query.filter_by(IdFrs=idfrs).all()


    # Prepare offer details for the chart
    chart_data = {
        'labels': [offer.Offer if offer.Offer != "NULL" else "No Offer Created" for offer in offers],  # x-axis labels (Offer IDs)
        'values': [float(offer.ValorisOffer) if offer.ValorisOffer and offer.ValorisOffer != "NULL" else 0.0 for offer in offers],  # y-axis values (Valorisation Offer)
        'offerStats': [offer.StatOffer for offer in offers],  # Additional data for tooltip
        'deviseValOffers': [offer.DeviseValorOffer for offer in offers]  # Additional data for tooltip
    }
    # Prepare offer details
    offer_details_list = []
    for offer in offers:
        offer_value = float(offer.ValorisOffer) if offer.ValorisOffer and offer.ValorisOffer != "NULL" else 0.0
        sales_value = float(offer.ValeurVenteCP) if offer.ValeurVenteCP and offer.ValeurVenteCP != "NULL" else 0.0

        # Calculate the difference and percentage change
        difference = sales_value - offer_value
        difference_percentage = "{:.2%}".format((difference / sales_value) if sales_value != 0 else 0.0)

        # Determine the currency symbol
        currency_symbol = "$" if offer.DeviseValorOffer == "USD" else "€" if offer.DeviseValorOffer == "EUR" else ""

        # Format the difference with the appropriate currency symbol
        formatted_difference = f"{currency_symbol} {difference:,.2f}"

        # Determine the sales change sign and color
        sales_change_sign = "▲" if difference >= 0 else "▼"
        sales_color = "green" if difference >= 0 else "red"

        # Build the offer details dictionary
        offer_details = {
            'idact': offer.IdAct,
            'offer': offer.Offer if offer.Offer != "NULL" else "No Offers",
            'offer_value': offer_value,
            'offer_status': offer.StatOffer,
            'currency': offer.DeviseValorOffer,
            'sales_value': sales_value,
            'difference': formatted_difference,
            'formatted_difference': difference_percentage,
            'salesChangeSign': sales_change_sign,
            'salesColor': sales_color
        }

        offer_details_list.append(offer_details)

    # Fetch and prepare litiges
    litiges = Supplier.query.with_entities(
        Supplier.IdAct,
        Supplier.Offer,
        Supplier.TypeLitige if Supplier.TypeLitige != "NULL" else "No Info",
        Supplier.StatutLitige if Supplier.StatutLitige != "NULL" else "No Info",
        Supplier.StatutLitigeClient if Supplier.StatutLitigeClient != "NULL" else "No Info",
        Supplier.StatutLitigeFournisseur if Supplier.StatutLitigeFournisseur != "NULL" else "No Info",
        Supplier.MntDemandeAvoir,
        Supplier.MntCreditNote,
        Supplier.MntRecupere,
        Supplier.MntRembouseClient
    ).filter_by(IdFrs=idfrs).distinct().all()

    litiges_list = [
        {
            'idact': litige.IdAct if litige.IdAct != "NULL" else "No Action",
            'offer': litige.Offer if litige.Offer != "NULL" else "No Offer",
            'TypeLitige': litige.TypeLitige if litige.TypeLitige != "NULL" else "No Info",
            'StatutLitige': litige.StatutLitige if litige.StatutLitige != "NULL" else "No Info" ,
            'StatutLitigeClient': litige.StatutLitigeClient if litige.StatutLitigeClient != "NULL" else "No Info",
            'StatutLitigeFournisseur': litige.StatutLitigeFournisseur  if litige.StatutLitigeFournisseur != "NULL" else "No Info",
            'MntDemandeAvoir': litige.MntDemandeAvoir,
            'MntCreditNote': litige.MntCreditNote,
            'MntRecupere': litige.MntRecupere,
            'MntRembouseClient': litige.MntRembouseClient
        }
        for litige in litiges
    ]

    return render_template(
        'home/supplier_details.html',
        supplier=supplier,
        offer_details_list=offer_details_list,
        litiges_list=litiges_list,
        supplier_data=json.dumps(supplier_data),
        stacked_bar_chart_data=json.dumps(stacked_bar_chart_data),
        donut_chart_data=json.dumps(donut_chart_data),
        pie_chart_data=json.dumps(pie_chart_data),
        statutact_chart_data=json.dumps(statutact_chart_data),
        chart_data=json.dumps(chart_data)
    )



@home_blueprint.route('/supplier/<string:idfrs>/chart-data')
def prod_chart_data(idfrs):
    # Query to get the required data
    idacts_affairs = Supplier.query.with_entities(Supplier.IdAct, Supplier.FrsFamilleProdMerged, Supplier.IdFrs).filter_by(IdFrs=idfrs).distinct().all()
 
    # Create labels based on unique combinations of FrsFamilleProdMerged and IdFrs
    unique_labels = list(set([(frs_famille_prod_merged, idfrs) for _, frs_famille_prod_merged, idfrs in idacts_affairs]))
 
    # Count occurrences for each label
    data_counts = [len([1 for _, frs_famille_prod_merged, idfrs in idacts_affairs if (frs_famille_prod_merged, idfrs) == label]) for label in unique_labels]
 
    # Create labels as strings in the format "FrsFamilleProdMerged-IdFrs"
    labels = [f"{frs_famille_prod_merged}" for frs_famille_prod_merged, idfrs in unique_labels]
 
    # Generate a list of colors (as many as needed)
    colors = [
        # Add your desired colors here or generate them dynamically
        'rgba(255, 99, 132, 0.6)',
        'rgba(54, 162, 235, 0.6)',
        'rgba(255, 206, 86, 0.6)',
        'rgba(75, 192, 192, 0.6)',
        'rgba(153, 102, 255, 0.6)',
        'rgba(255, 159, 64, 0.6)'
    ]
 
    # Ensure you have enough colors for your data points
    if len(colors) < len(labels):
        import random
        def random_color():
            return f'rgba({random.randint(0, 255)}, {random.randint(0, 255)}, {random.randint(0, 255)}, 0.6)'
        colors = [random_color() for _ in range(len(labels))]
 
    # Construct the data for the donut chart
    donut_chart_data = {
        'labels': labels,
        'datasets': [{
            'label': 'Supplier Details',
            'data': data_counts,
            'backgroundColor': colors[:len(labels)],  # Use only as many colors as needed
            'borderWidth': 1
        }]
    }
 
    return jsonify(donut_chart_data)