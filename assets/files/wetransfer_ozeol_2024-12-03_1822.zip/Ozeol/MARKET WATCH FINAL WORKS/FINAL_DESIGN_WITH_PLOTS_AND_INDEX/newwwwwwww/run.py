import time
import random
from flask import Flask, render_template
import pandas as pd
from app import create_app

# Initialize the Flask application with custom static and template folders
app = Flask(__name__, static_folder='apps/static', template_folder='apps/home/templates')
app = create_app()

def test_db_connection():
    """Test the database connection by counting the number of suppliers."""
    with app.app_context():
        try:
            from apps.models import Supplier
            suppliers_count = Supplier.query.count()
            print(f"Database connection successful. Found {suppliers_count} suppliers.")
        except Exception as e:
            print(f"Database connection failed: {str(e)}")
@app.route('/')
def index():
    """Render the index template with data from the DataFrame."""
    labels = df['label'].tolist()
    data = df['data'].tolist()
    return render_template('index.html', labels=labels, data=data)
if __name__ == "__main__":
    app.run(debug=True)