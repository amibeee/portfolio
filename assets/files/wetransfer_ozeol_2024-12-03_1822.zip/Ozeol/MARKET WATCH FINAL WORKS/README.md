# Market Watch Ozeol.com

## Project Overview

The Market Watch Ozeol.com project aims to develop a comprehensive Market Surveillance Tool to monitor and display the liquidation status of companies. This tool aggregates data from diverse sources, including merchant websites, to provide timely and actionable insights into market opportunities.

## Table of Contents

- [Installation](#installation)
- [Technologies](#technologies)
- [Usage](#usage)
- [License](#license)
- [Contact](#contact)

## Installation

Follow these steps to set up the project locally:

1. **Clone the Repository:**

   ```bash
   git clone https://github.com/your-repository-url.git
   ```

2. **Navigate to the Project Directory:**

   ```bash
   cd FINAL DESIGN_WITH_PLOTS_AND_INDEX/newwwwwwww
   ```
3. **Install the Required Libraries:**

   ```bash
   pip install Flask pandas Flask-SQLAlchemy SQLAlchemy Flask-Login python-dotenv requests flask_sqlalchemy mysqlclient flask_wtf flask_dance
   ```

## Technologies

This project utilizes the following technologies:

- **Flask**: A lightweight WSGI web application framework.
- **JavaScript (JS)**: For dynamic web content and interactivity.
- **SQL**: For database management.
- **Bootstrap**: For responsive and modern UI design.

## Usage

To launch the application, use the following command:

```bash
python run.py
```
### Demo & Screenshots

- **Dark Mode:**
  ![Dark mode](image.png)

- **Light Mode:**
  ![Light mode](image-1.png)

- **Data Table:**
  ![Table](image-2.png)

- **Dashboard:**
  ![Dashboard](image-3.png)

## Contact

For any inquiries or support, please contact:

- **Nawress Abbes**: nawresabbes60@gmail.com, +216 52095051
- **Nour El Islem Zarif**: zarifnour12@gmail.com, +216 26882868
- **Feriel Abbes**: abbess.feriel@gmail.com, +216 52073935
- **Rima Fathallah**: rimafathallah.9@gmail.com +216 56479019

Feel free to reach out with any questions or feedback!