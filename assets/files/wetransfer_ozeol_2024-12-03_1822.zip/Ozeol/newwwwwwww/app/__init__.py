# Import
from flask import Flask, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from app.config import Config
from flask_login import LoginManager

# Initialize SQLAlchemy object
db = SQLAlchemy()
# Initialize LoginManager object
loginmanager = LoginManager()


def create_app():
    # Create a Flask application instance
    app = Flask(__name__)

    # Initialize LoginManager with the app
    loginmanager.init_app(app)
    app.config.from_object(Config)
    db.init_app(app)

    from apps.home.routes import home_blueprint
    # Register the blueprint with the app
    app.register_blueprint(home_blueprint)

    # Define a route to serve static files
    @app.route('/static/<path:filename>')
    def serve_static(filename):
        # Serve the requested static file from the 'static' directory
        return send_from_directory('static', filename)

    return app
