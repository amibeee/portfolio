# Import moduls
import os
from dotenv import load_dotenv

# Load environment variables from a .env file into the environment
load_dotenv()


class Config:
    # Set a secret key for the app, fallback to 'test' if not set in the environment
    SECRET_KEY = os.environ.get('test') or 'test'
    # Set the database URI, fallback to a default MySQL URI if not set in the environment
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL') or 'mysql://root@localhost/ozeol_db1'
    # Disable SQLAlchemy event system to save memory
    SQLALCHEMY_TRACK_MODIFICATIONS = False
