document.addEventListener("DOMContentLoaded", function () {
    var demo = {
        themeColors: [
            'rgba(234, 84, 45, 0.4)',
            'rgba(255, 99, 132, 0.4)',
            'rgba(255, 159, 64, 0.4)',
            'rgba(75, 192, 192, 0.4)',
            'rgba(153, 102, 255, 0.4)',
            'rgba(255, 205, 86, 0.4)'
        ],

        shuffleArray: function (array) {
            for (let i = array.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [array[i], array[j]] = [array[j], array[i]];
            }
            return array;
        },

        getRandomizedColors: function (length) {
            let shuffledColors = this.shuffleArray([...this.themeColors]);
            return Array.from({ length }, (_, i) => shuffledColors[i % shuffledColors.length]);
        },

        initStackedBarChart: function (chartData) {
            var ctx = document.getElementById('stackedbarchart');
            if (!ctx) {
                console.error("Canvas element with ID 'stackedbarchart' not found.");
                return;
            }

            var randomizedColors = this.getRandomizedColors(chartData.datasets.length);

            new Chart(ctx.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: chartData.labels,
                    datasets: chartData.datasets.map((dataset, index) => ({
                        ...dataset,
                        backgroundColor: randomizedColors[index],
                    }))
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: { stacked: true },
                        y: { stacked: true }
                    }
                }
            });
        },

        initDoughnutChart: function (chartData) {
            var ctx = document.getElementById('donutchart');
            if (!ctx) {
                console.error("Canvas element with ID 'donutchart' not found.");
                return;
            }

            var randomizedColors = this.getRandomizedColors(chartData.datasets[0].data.length);

            new Chart(ctx.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        data: chartData.datasets[0].data,
                        backgroundColor: randomizedColors
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        },

        initStatutactPieChart: function (statutactChartData) {
            var ctx = document.getElementById('statutactChart');
            if (!ctx) {
                console.error("Canvas element with ID 'statutactChart' not found.");
                return;
            }

            var randomizedColors = this.getRandomizedColors(statutactChartData.labels.length);

            new Chart(ctx.getContext('2d'), {
                type: 'pie',
                data: {
                    ...statutactChartData,
                    datasets: statutactChartData.datasets.map(dataset => ({
                        ...dataset,
                        backgroundColor: randomizedColors,
                    }))
                },
                options: {
                    responsive: true
                }
            });
        },

        initMap: function (supplierData) {
            var mapElement = document.getElementById('supplier-map');
            if (!mapElement) {
                console.error("Element with ID 'supplier-map' not found.");
                return;
            }

            var map = L.map('supplier-map').setView([20, 0], 2);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '© OpenStreetMap'
            }).addTo(map);

            supplierData.forEach(supplier => {
                L.marker(supplier.coordinates)
                    .addTo(map)
                    .bindPopup(`${supplier.name}<br>${supplier.country}`);
            });
        }
    };

    // Example Usage
    const exampleBarData = {
        labels: ["January", "February", "March"],
        datasets: [
            { label: "Dataset 1", data: [10, 20, 30] },
            { label: "Dataset 2", data: [15, 25, 35] }
        ]
    };

    const exampleDoughnutData = {
        labels: ["Red", "Blue", "Yellow"],
        datasets: [{ data: [300, 50, 100] }]
    };

    const examplePieData = {
        labels: ["Active", "Inactive"],
        datasets: [{ data: [75, 25] }]
    };

    const exampleSupplierData = [
        { name: "Supplier 1", country: "USA", coordinates: [37.7749, -122.4194] },
        { name: "Supplier 2", country: "France", coordinates: [48.8566, 2.3522] }
    ];

    demo.initStackedBarChart(exampleBarData);
    demo.initDoughnutChart(exampleDoughnutData);
    demo.initStatutactPieChart(examplePieData);
    demo.initMap(exampleSupplierData);
});
