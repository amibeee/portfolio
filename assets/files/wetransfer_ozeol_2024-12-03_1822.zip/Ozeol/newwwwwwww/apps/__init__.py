from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from app.config import Config
from app import db
import logging
import sqlalchemy
from importlib import import_module

# Configure logging to show SQLAlchemy engine log messages
logging.basicConfig()
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)


def register_blueprints(app):
    """
    Registers blueprints for the given Flask application.

    Parameters:
    app (Flask): The Flask application instance to which blueprints will be registered.
    """
    for module_name in ('authentication', 'home'):
        # Dynamically import the routes module for each blueprint
        module = import_module('apps.{}.routes'.format(module_name))
        # Register the blueprint with the Flask app
        app.register_blueprint(module.blueprint)


def create_app(config_class=Config):
    """
    Creates and configures a Flask application instance.

    Parameters:
    config_class (Config): The configuration class to use for the app.

    Returns:
    Flask: The configured Flask application instance.
    """
    # Create a new Flask application instance
    app = Flask(__name__, static_folder='apps/static',
                template_folder='templates')
    # Load configuration from the specified config class
    app.config.from_object(config_class)

    with app.app_context():
        try:
            # Try to connect to the database using the URI from the config
            engine = sqlalchemy.create_engine(
                app.config['SQLALCHEMY_DATABASE_URI'])
            engine.connect()
            print("Database connection successful")
        except sqlalchemy.exc.SQLAlchemyError as e:
            # Print an error message and raise the exception if the connection fails
            print(f"Database connection failed: {str(e)}")
            raise e

        # Initialize the SQLAlchemy extension with the Flask app
        db.init_app(app)

        # Import and register the home blueprint
        from apps.home.routes import home_blueprint
        app.register_blueprint(home_blueprint)

        # Create database tables based on the SQLAlchemy models
        db.create_all()

    return app
