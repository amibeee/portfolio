# Import the Blueprint class from the Flask framework
from flask import Blueprint

# Create a new Blueprint instance for the authentication feature
blueprint = Blueprint(
    'authentication_blueprint',  
    __name__,                    
    url_prefix=''                
)
