# Import
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import DataRequired

# Define a form class for user login, inheriting from FlaskForm


class LoginForm(FlaskForm):
    # Define a text field
    username = StringField(
        'Username',
        id='username_login',
        validators=[DataRequired()]
    )

    # Define a password field
    password = PasswordField(
        'Password',
        id='pwd_login',
        validators=[DataRequired()]
    )
