# Import necessary classes and functions from various libraries
from flask_login import UserMixin
from sqlalchemy.orm import relationship
from flask_dance.consumer.storage.sqla import OAuthConsumerMixin
from app import db, loginmanager

# Define a Users model for SQLAlchemy, which also implements UserMixin for Flask-Login


class Users(db.Model, UserMixin):

    # Define the name of the database table ( accounts)
    __tablename__ = 'accounts'

    # Define the columns for the 'accounts' table
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True)
    password = db.Column(db.LargeBinary)
    email = db.Column(db.String(64), unique=True)


# Define a user loader function for Flask-Login
@loginmanager.user_loader
def user_loader(id):
    # Query the database for a user with the given ID
    return Users.query.filter_by(id=id).first()


# Define a request loader function for Flask-Login
@loginmanager.request_loader
def request_loader(request):
    # Get the username from the request form data
    username = request.form.get('username')

    # Query the database for a user with the given username
    user = Users.query.filter_by(username=username).first()

    # Return the user object if found, otherwise return None
    return user if user else None
