def verify_pass(provided_password, stored_password):
    """
    Verifies if the provided password matches the stored password.

    Parameters:
    provided_password (str): The password input by the user.
    stored_password (str): The correct password stored in the system.

    Returns:
    bool: True if the provided password matches the stored password, False otherwise.
    """
    # Compare the provided password with the stored password
    return provided_password == stored_password
