# Import models
from . import routes
from flask import Blueprint
from apps.models import Supplier


def fetch_supplier_data(idfrs):
    """
    Fetch supplier data based on the given ID.

    Args:
        idfrs (int): The ID of the supplier to fetch.

    Returns:
        dict: A dictionary containing the supplier's ID if found.
        None: If no supplier is found with the given ID.
    """
    # Query the database to get the Supplier object with the given ID
    supplier = Supplier.query.get(idfrs)

    # Check if a supplier was found
    if supplier:
        # Return a dictionary with the supplier's ID
        return {
            'IdFrs': supplier.IdFrs,
        }
    else:
        # Return None if no supplier was found
        return None


# Create a Blueprint instance for the 'home' section of the application
home_blueprint = Blueprint('home', __name__, template_folder='templates')
