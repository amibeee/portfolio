import time
import random 
import csv
from flask import Flask, render_template
from flask_socketio import SocketIO, emit
import pandas as pd
from app import create_app

# Initialize the Flask application with custom static and template folders
app = Flask(__name__, static_folder='apps/static',
            template_folder='apps/home/templates')
# Create the app with the factory function
app = create_app()
# Initialize SocketIO with the Flask app
socketio = SocketIO(app)


def test_db_connection():
    """Test the database connection by counting the number of suppliers."""
    with app.app_context():
        try:
            from apps.models import Supplier
            suppliers_count = Supplier.query.count()
            print(
                f"Database connection successful. Found {suppliers_count} suppliers.")
        except Exception as e:
            print(f"Database connection failed: {str(e)}")


# Load your CSV data into a pandas DataFrame
df = pd.read_csv('s.csv')


@socketio.on('request_data')
def handle_data_request():
    """Handle incoming requests for data and emit the data from the CSV file."""
    data = []
    with open('s.csv', 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            # Append each row to the data list
            data.append(row)
    # Send data to the connected client
    emit('data_update', data)


@socketio.on('connect')
def handle_connect():
    """Handle a new client connection."""
    print('Client connected')


@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection."""
    print('Client disconnected')


def send_realtime_data():
    """Periodically send data points to clients in real-time."""
    labels = df['label'].tolist()  # Extract labels from DataFrame
    data = df['data'].tolist()  # Extract data values from DataFrame
    index = 0
    while True:
        data_point = {
            'label': labels[index],
            'data': data[index]
        }
        # Emit data point to connected clients
        socketio.emit('data_update', data_point)
        # Update index and wrap around if necessary
        index = (index + 1) % len(labels)
        # Pause for 0.5 seconds before sending the next data point
        time.sleep(0.5)


if __name__ == "__main__":
    # Start the background task for sending real-time data
    socketio.start_background_task(target=send_realtime_data)
    # Run the Flask application with SocketIO support
    socketio.run(app, debug=True)
